-- & en T-SQL (explicación)
PRINT '&& no se usa en T-SQL, en su lugar se utiliza AND para operaciones lógicas.';
PRINT 'Ejemplo: WHERE condicion1 = 1 AND condicion2 = 2';